/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SMD_First_Assignment;

/**
 *
 * @author DANI
 */
public interface Animal {
   public void HasFur();  //tell wether the animal has fur
    public  int getNumberOfEyes();  //gives the count of eyes
   public int getNumberOfLegs();   //gives the count of legs
  public  void BasicWayOfTravel();    //tells how the animal travels e.g walks,swmims,flys e.t.c
}
