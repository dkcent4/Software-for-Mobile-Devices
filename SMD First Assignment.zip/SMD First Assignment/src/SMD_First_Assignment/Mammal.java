/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SMD_First_Assignment;

/**
 *
 * @author DANI
 */
public interface Mammal  {
   public void meansOfBreathing();  //tells how does the mammal breathe e.g through nose,gills e.t.c
    public void hasWings();  //tells wether the mammal has wings
    public void canCrawlOnWalls();  //tells wether the mammal can crawl on walls
}
